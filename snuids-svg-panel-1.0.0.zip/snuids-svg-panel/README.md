# SVG Panel


This panel dispays data as a colored svg using a customizable threshold. Compatible with Grafana 7.0+

### Dashboard

![Screenshot](https://raw.githubusercontent.com/snuids/grafana-svg-panel/master/docs/svg-screenshot-1.png?raw=true "Screenshot")

### Parameters

![Screenshot](https://raw.githubusercontent.com/snuids/grafana-svg-panel/master/docs/svg-screenshot-2.png?raw=true "Screenshot")

